# k8s-lab — 재사용 가능한 Kubernetes HA 클러스터 자동화 (Ansible roles)

WSL Ubuntu 제어 노드에서 Windows DC(DNS), vSphere(VM 배포), Ubuntu 24.04 노드(LB/컨트롤플레인/워커)를
일괄 구성한다. 다음 클러스터가 필요하면 `inventory.ini` 와 `group_vars/all.yml` 만 수정해 재사용한다.

## 디렉토리 구조

```
k8s-lab/
├── ansible.cfg              # roles_path, collections_path, host_key_checking=False 등
├── requirements.yml         # 필요한 컬렉션 목록
├── inventory.ini            # 호스트/그룹 (재사용 시 IP만 변경)
├── group_vars/
│   ├── all.yml              # virtual_ip, pod_cidr, k8s 버전, calico 버전, primary_master
│   ├── dc_svrs.yml          # Windows DC 접속(psrp/HTTPS/RootCA)
│   └── k8s_nodes.yml        # Ubuntu 노드 접속(키 + sudo)
├── roles/
│   ├── dns_records/         # win_dns_record 로 A/PTR 등록
│   ├── vm_deploy/           # community.vmware 로 VM 배포
│   ├── ssh_access/          # 제어 노드 공개키 배포
│   ├── common_k8s/          # [핵심 공용] swap/모듈/sysctl/containerd/kube 패키지 (CP·워커 공유)
│   ├── loadbalancer/        # HAProxy + Keepalived (+ 템플릿)
│   ├── control_plane/       # kubeadm init + control-plane join + Calico
│   ├── worker/              # kubeadm join (워커)
│   └── monitoring/          # Helm 으로 kube-prometheus-stack(Prometheus+Grafana) 배포
├── 00-provision-dns.yml     # (1) DNS
├── 01-provision-vms.yml     # (2) VM 배포
├── 02-ssh-access.yml        # (3) SSH 키 배포
├── 03-loadbalancer.yml      # (4) LB
├── 04-control-plane.yml     # (5) 컨트롤플레인 HA
├── 05-workers.yml           # (6) 워커
├── 10-monitoring.yml        # (10) 모니터링 스택 (클러스터 Ready 후)
└── site.yml                 # (3)~(6) 일괄 실행
```

버전 기준: Kubernetes **v1.36**, Calico **v3.32.0** (group_vars/all/vars.yml 에서 조정).

## 사전 준비 (최초 1회)

```bash
# 제어 노드 기본 구성은 기존 setup-ansible-control-node.sh 로 끝나 있다고 가정
ansible-galaxy collection install -r requirements.yml -p ./collections
sudo apt install -y sshpass            # 최초 비밀번호 접속용

# 비밀값을 vault 로 암호화 (한 번만)
cp group_vars/all/vault.yml.example group_vars/all/vault.yml
# vault.yml 의 비밀번호를 실제 값으로 수정 후:
ansible-vault encrypt group_vars/all/vault.yml
#  - 값 변경:   ansible-vault edit group_vars/all/vault.yml
#  - 자동 입력: echo '볼트암호' > ~/.vault_pass && chmod 600 ~/.vault_pass
#               후 ansible.cfg 의 vault_password_file 주석 해제 (그러면 --ask-vault-pass 불필요)
```

## 실행 순서

비밀값이 vault 에 있으므로 `--ask-vault-pass`(또는 vault_password_file)만 있으면 됩니다.
SSH_PASSWORD 같은 환경변수 주입은 더 이상 필요 없습니다.

```bash
# (1) DNS
ansible-playbook 00-provision-dns.yml --ask-vault-pass

# (2) VM 배포 (student_id 확인!)
ansible-playbook 01-provision-vms.yml --ask-vault-pass
#     배포된 VM 부팅/IP 할당까지 1~2분 대기

# (3)~(6) 리눅스 측 전체 구성 — 한 번에
ansible-playbook site.yml --ask-vault-pass

#   단계별 실행도 동일하게 --ask-vault-pass 만 붙이면 됨
```

## (10) 모니터링 스택 (선택, 클러스터 Ready 후)

```bash
ansible-playbook 10-monitoring.yml --ask-vault-pass
# Grafana 접속:  http://<워커노드IP>:32000   (admin / vault_grafana_password)
#   예) http://10.10.10.31:32000
```

NodePort 32000 은 워커 방화벽(30000:32767)으로 열려 있으므로 **워커 노드 IP** 로 접속합니다.
영구볼륨(StorageClass)이 없는 랩 환경이라 데이터는 emptyDir(비영속)로 동작합니다.

## 확인

```bash
ssh ubuntu@10.10.10.21 "sudo kubectl get nodes -o wide"
# CP 3대 + Worker 3대가 Ready 면 완료
```

## 다음 클러스터에 재사용하는 법

1. `inventory.ini` 의 IP/호스트명 변경
2. `group_vars/all/vars.yml` 의 `virtual_ip`, `pod_cidr`, `k8s_pkg_minor`, `calico_version` 조정
3. `00`/`01` 의 `dns_records`/`vm_list` 와 `student_id` 만 맞추고 위 순서대로 실행

## 설계 메모

- 비밀값(Windows/SSH/vCenter)은 `group_vars/all/vault.yml` 에 ansible-vault 로 암호화. 평문
  `vault.yml.example` 을 복사·암호화해서 쓰며, 실제 `vault.yml` 은 `.gitignore` 로 커밋 제외.
- `common_k8s` 가 컨트롤플레인/워커 공통 준비를 담당(중복 제거). pause 이미지는 하드코딩 대신
  `kubeadm config images list` 가 알려주는 값을 사용해 K8s 버전(현재 v1.36)에 자동 정합.
- `common_k8s` 끝의 `meta: flush_handlers` 로 containerd 재시작을 kubeadm 실행 전에 반영.
- `primary_master`(control_plane 첫 호스트)가 init/Calico/토큰을 전담, 나머지는 hostvars 로 조인.
- Calico(v3.32) 이미지는 quay.io 로 치환되어 Docker Hub rate limit 영향 없음. K8s 1.36 은
  MutatingAdmissionPolicy 가 GA 기본 활성이라 매니페스트 설치가 정상 동작.
- keepalived 헬스체크 `weight` 는 `-20`(기본). MASTER/BACKUP priority 차이(10)보다 크므로,
  HAProxy 프로세스만 죽어도 VIP 가 BACKUP 으로 페일오버됨(`keepalived_check_weight` 로 조정 가능).
